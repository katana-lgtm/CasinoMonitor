#include <jni.h>
#include <string>
#include <unistd.h>
#include <pthread.h>
#include <stdint.h>
#include <cstdio>

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_phantom_cazinomonitor_OverlayService_getModuleBaseNative(JNIEnv *env, jobject thiz, jstring module_name) {
    const char *nativeString = env->GetStringUTFChars(module_name, 0);
    FILE *fp = fopen("/proc/self/maps", "rt");
    if (!fp) {
        env->ReleaseStringUTFChars(module_name, nativeString);
        return 0;
    }

    uintptr_t baseAddress = 0;
    char line[512];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, nativeString)) {
            char *ptr = strtok(line, "-");
            if (ptr) {
                baseAddress = strtoull(ptr, nullptr, 16);
                break;
            }
        }
    }
    fclose(fp);
    env->ReleaseStringUTFChars(module_name, nativeString);
    return (jlong)baseAddress;
}

template <typename T>
bool ReadMemoryStealth(uintptr_t address, T& output) {
    if (address == 0) return false;
    volatile T* targetPtr = reinterpret_cast<volatile T*>(address);
    output = *targetPtr;
    return true;
}

void* MonitoringThread(void* arg) {
    uintptr_t libBase = reinterpret_cast<uintptr_t>(arg);
    
    uintptr_t tableManagerOffset = 0x00B5A20;
    uintptr_t diceOutcomeOffset = 0x0044;

    while (true) {
        uintptr_t tableManager = 0;
        if (ReadMemoryStealth(libBase + tableManagerOffset, tableManager) && tableManager != 0) {
            int diceResult = 0;
            ReadMemoryStealth(tableManager + diceOutcomeOffset, diceResult);
        }
        usleep(50000);
    }
    return nullptr;
}

JNIEXPORT void JNICALL
Java_com_phantom_cazinomonitor_OverlayService_startStealthEngine(JNIEnv *env, jobject thiz, jlong module_base) {
    pthread_t thread;
    pthread_create(&thread, nullptr, MonitoringThread, reinterpret_cast<void*>(module_base));
    pthread_detach(thread);
}

}