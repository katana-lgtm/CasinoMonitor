package com.phantom.cazinomonitor;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

public class OverlayService extends Service {
    private WindowManager windowManager;
    private View overlayView;
    private TextView statusTextView;

    static {
        System.loadLibrary("cazinomonitor");
    }

    public native void startStealthEngine(long moduleBase);
    public native long getModuleBaseNative(String moduleName);

    @Override
    public void onCreate() {
        super.onCreate();
        
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O ?
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 40;
        params.y = 40;

        statusTextView = new TextView(this);
        statusTextView.setText("PHANTOM: Waiting for libsamp.so...");
        statusTextView.setTextColor(0xFF00FF00);
        statusTextView.setTextSize(14);
        statusTextView.setShadowLayer(4f, 1f, 1f, 0xFF000000);

        windowManager.addView(statusTextView, params);

        new Thread(() -> {
            long base = 0;
            while (base == 0) {
                base = getModuleBaseNative("libsamp.so");
                try { Thread.sleep(200); } catch (InterruptedException e) {}
            }
            startStealthEngine(base);
        }).start();
    }

    public void updateOverlayData(String text) {
        if (statusTextView != null) {
            statusTextView.post(() -> statusTextView.setText(text));
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (statusTextView != null && windowManager != null) {
            windowManager.removeView(statusTextView);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}